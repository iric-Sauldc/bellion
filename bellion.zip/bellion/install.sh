#!/usr/bin/env bash
# bellion — instalador
# NO modifica .bashrc ni .zshrc ni ningún dotfile del usuario
# Usa venv aislado — no rompe el Python del sistema

set -euo pipefail

INSTALL_DIR="/usr/local/share/bellion"
VENV_DIR="$INSTALL_DIR/venv"
BIN_BELLION="/usr/local/bin/bellion"
CNF_ORIG="/usr/lib/command-not-found"
CNF_BACKUP="/usr/lib/command-not-found.orig"
FISH_FUNC_DIR="/usr/share/fish/vendor_functions.d"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ERRORS=0

# ── Colores ───────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'
ok()   { echo -e "  ${GREEN}✓${RESET} $*"; }
warn() { echo -e "  ${YELLOW}⚠${RESET} $*"; ERRORS=$((ERRORS+1)); }
err()  { echo -e "  ${RED}✗${RESET} $*"; }
step() { echo -e "\n${BOLD}→ $*${RESET}"; }

# ── Debe correr como root ─────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    echo "Este instalador necesita sudo para instalar en /usr/local/"
    exec sudo bash "$0" "$@"
fi

echo -e "${BOLD}"
echo "╔══════════════════════════════════════╗"
echo "║        bellion — instalador          ║"
echo "╚══════════════════════════════════════╝"
echo -e "${RESET}"

# ─────────────────────────────────────────────────────────────────
# PASO 1 — Detectar versión de Python y garantizar que venv funciona
# Ubuntu separa python3-venv en paquetes por versión (python3.13-venv, etc.)
# python3 -m venv --help pasa aunque el venv esté roto; hay que hacer un test real.
# ─────────────────────────────────────────────────────────────────
step "Verificando Python y venv..."

if ! command -v python3 &>/dev/null; then
    err "python3 no encontrado. Instala con: sudo apt install python3"
    exit 1
fi

PY_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>/dev/null) || {
    err "No se pudo determinar la versión de Python"
    exit 1
}
ok "Python $PY_VERSION detectado"

# Test real de venv (--help no es suficiente en Ubuntu)
VENV_TEST=$(mktemp -d)
VENV_OK=false
if python3 -m venv "$VENV_TEST" --without-pip 2>/dev/null && [[ -x "$VENV_TEST/bin/python3" ]]; then
    VENV_OK=true
fi
rm -rf "$VENV_TEST"

if [[ "$VENV_OK" == false ]]; then
    step "Instalando python${PY_VERSION}-venv..."
    if apt-get install -y "python${PY_VERSION}-venv" -q 2>/dev/null; then
        ok "python${PY_VERSION}-venv instalado"
    elif apt-get install -y python3-venv python3-full -q 2>/dev/null; then
        ok "python3-full instalado como fallback"
    else
        err "No se pudo instalar venv para Python $PY_VERSION"
        err "Intenta manualmente: sudo apt install python${PY_VERSION}-venv"
        exit 1
    fi

    # Verificar de nuevo después de instalar
    VENV_TEST2=$(mktemp -d)
    if ! python3 -m venv "$VENV_TEST2" --without-pip 2>/dev/null || [[ ! -x "$VENV_TEST2/bin/python3" ]]; then
        rm -rf "$VENV_TEST2"
        err "venv sigue sin funcionar tras instalar el paquete"
        err "Intenta: sudo apt install python${PY_VERSION}-venv python3-full"
        exit 1
    fi
    rm -rf "$VENV_TEST2"
    ok "venv verificado correctamente"
else
    ok "venv funciona correctamente"
fi

# ─────────────────────────────────────────────────────────────────
# PASO 2 — Crear venv e instalar dependencias
# ─────────────────────────────────────────────────────────────────
step "Creando entorno virtual Python..."

mkdir -p "$INSTALL_DIR"

# Limpiar venv roto de intentos anteriores
if [[ -d "$VENV_DIR" ]]; then
    warn "Venv existente encontrado, eliminando para crear uno limpio..."
    rm -rf "$VENV_DIR"
fi

python3 -m venv "$VENV_DIR" 2>/dev/null || {
    err "Falló la creación del venv en $VENV_DIR"
    exit 1
}
ok "Venv creado en $VENV_DIR"

# Verificar que pip existe en el venv
if [[ ! -x "$VENV_DIR/bin/pip" ]]; then
    err "pip no encontrado en el venv"
    err "Intenta: sudo apt install python${PY_VERSION}-venv python3-full"
    exit 1
fi

step "Instalando dependencias (textual, rich)..."
"$VENV_DIR/bin/pip" install --upgrade pip --quiet 2>/dev/null || true
"$VENV_DIR/bin/pip" install textual rich --quiet 2>/dev/null || {
    # Reintento con output visible si falla
    warn "Primer intento silencioso falló, reintentando con output..."
    "$VENV_DIR/bin/pip" install textual rich || {
        err "No se pudo instalar textual/rich"
        err "Verifica tu conexión a internet"
        exit 1
    }
}

# Verificar imports reales
"$VENV_DIR/bin/python3" -c "import textual, rich" 2>/dev/null || {
    err "Las dependencias se instalaron pero no importan correctamente"
    exit 1
}
ok "textual y rich instalados y verificados"
ok "Python del sistema NO fue modificado"

# ─────────────────────────────────────────────────────────────────
# PASO 3 — apt-file (opcional, mejora resultados)
# ─────────────────────────────────────────────────────────────────
step "Verificando apt-file..."
if ! command -v apt-file &>/dev/null; then
    echo "  → Instalando apt-file..."
    if apt-get install -y apt-file -q 2>/dev/null; then
        ok "apt-file instalado"
        echo "  → Actualizando base de datos de apt-file (puede tardar ~1 min)..."
        apt-file update -q 2>/dev/null && ok "apt-file actualizado" || \
            warn "apt-file update falló — las búsquedas usarán apt-cache como fallback"
    else
        warn "apt-file no disponible — se usará apt-cache como fallback"
    fi
else
    ok "apt-file disponible"
fi

# ─────────────────────────────────────────────────────────────────
# PASO 4 — Instalar bellion.py y launcher
# ─────────────────────────────────────────────────────────────────
step "Instalando bellion..."

if [[ ! -f "$SCRIPT_DIR/bellion.py" ]]; then
    err "bellion.py no encontrado en $SCRIPT_DIR"
    exit 1
fi

cp "$SCRIPT_DIR/bellion.py" "$INSTALL_DIR/bellion.py"
chmod 644 "$INSTALL_DIR/bellion.py"

# Verificar que el script es válido antes de instalar el launcher
"$VENV_DIR/bin/python3" -m py_compile "$INSTALL_DIR/bellion.py" 2>/dev/null || {
    err "bellion.py tiene errores de sintaxis"
    exit 1
}

# Launcher: usa el Python del venv directamente
cat > "$BIN_BELLION" << LAUNCHER
#!/usr/bin/env bash
exec /usr/local/share/bellion/venv/bin/python3 /usr/local/share/bellion/bellion.py "\$@"
LAUNCHER
chmod 755 "$BIN_BELLION"

# Prueba de ejecución básica
if ! "$BIN_BELLION" --version &>/dev/null; then
    warn "El launcher no responde a --version (puede ser normal si textual requiere terminal)"
fi
ok "bellion instalado en $BIN_BELLION"

# ─────────────────────────────────────────────────────────────────
# PASO 5 — Hook command-not-found para bash y zsh
# ─────────────────────────────────────────────────────────────────
step "Configurando hook command-not-found (bash/zsh)..."

if [[ -f "$CNF_ORIG" ]]; then
    if [[ ! -f "$CNF_BACKUP" ]]; then
        cp "$CNF_ORIG" "$CNF_BACKUP"
        chmod --reference="$CNF_ORIG" "$CNF_BACKUP" 2>/dev/null || chmod 755 "$CNF_BACKUP"
        ok "Original respaldado en $CNF_BACKUP"
    else
        ok "Respaldo ya existía en $CNF_BACKUP"
    fi
else
    warn "/usr/lib/command-not-found no existe en este sistema"
    warn "El hook se instalará de todas formas"
fi

cat > "$CNF_ORIG" << 'HOOK'
#!/usr/bin/env bash
# bellion hook — command-not-found handler
# Original respaldado en: /usr/lib/command-not-found.orig
CMD="${1:-}"

# Sin comando, sin terminal interactiva, o sin bellion → usar original o salir
if [[ -z "$CMD" ]] || [[ ! -t 1 ]] || ! command -v bellion &>/dev/null 2>&1; then
    if [[ -x /usr/lib/command-not-found.orig ]]; then
        exec /usr/lib/command-not-found.orig "$@"
    fi
    [[ -n "$CMD" ]] && echo "${CMD}: comando no encontrado" >&2
    exit 127
fi

# Ignorar comandos que parecen rutas (./algo, /usr/bin/algo)
if [[ "$CMD" == */* ]]; then
    if [[ -x /usr/lib/command-not-found.orig ]]; then
        exec /usr/lib/command-not-found.orig "$@"
    fi
    echo "${CMD}: comando no encontrado" >&2
    exit 127
fi

echo ""
echo "  '$CMD' no encontrado — buscando paquetes disponibles..."
echo ""
bellion "$CMD"
exit 127
HOOK

chmod 755 "$CNF_ORIG"

# Verificar que nuestro hook está en el archivo
if grep -q "bellion" "$CNF_ORIG" 2>/dev/null; then
    ok "Hook activo para bash y zsh"
    ok "Sin modificar .bashrc ni .zshrc"
else
    err "El hook no se escribió correctamente en $CNF_ORIG"
    ERRORS=$((ERRORS+1))
fi

# ─────────────────────────────────────────────────────────────────
# PASO 6 — Soporte Fish (solo si está instalado)
# ─────────────────────────────────────────────────────────────────
if command -v fish &>/dev/null; then
    step "Fish detectado — instalando fish_command_not_found..."
    mkdir -p "$FISH_FUNC_DIR"
    cat > "$FISH_FUNC_DIR/fish_command_not_found.fish" << 'FISH'
function fish_command_not_found
    set cmd $argv[1]

    # Ignorar rutas
    if string match -q '*/*' $cmd
        __fish_default_command_not_found_handler $argv
        return
    end

    if command -v bellion > /dev/null 2>&1
        echo ""
        echo "  '$cmd' no encontrado — buscando paquetes disponibles..."
        echo ""
        bellion $cmd
    else
        __fish_default_command_not_found_handler $argv
    end
end
FISH
    ok "fish_command_not_found instalado en $FISH_FUNC_DIR"
fi

# ─────────────────────────────────────────────────────────────────
# PASO 7 — Verificación final completa
# ─────────────────────────────────────────────────────────────────
step "Verificación final..."
VERIFY_ERRORS=0

[[ -f "$INSTALL_DIR/bellion.py" ]]       && ok "bellion.py presente"    || { err "bellion.py ausente";    VERIFY_ERRORS=$((VERIFY_ERRORS+1)); }
[[ -x "$BIN_BELLION" ]]                   && ok "launcher ejecutable"    || { err "launcher no ejecutable"; VERIFY_ERRORS=$((VERIFY_ERRORS+1)); }
[[ -d "$VENV_DIR" ]]                      && ok "venv presente"          || { err "venv ausente";           VERIFY_ERRORS=$((VERIFY_ERRORS+1)); }
[[ -x "$VENV_DIR/bin/python3" ]]          && ok "Python en venv OK"      || { err "Python en venv ausente"; VERIFY_ERRORS=$((VERIFY_ERRORS+1)); }
"$VENV_DIR/bin/python3" -c "import textual, rich" 2>/dev/null \
                                           && ok "Dependencias OK"        || { err "Dependencias fallidas";  VERIFY_ERRORS=$((VERIFY_ERRORS+1)); }
grep -q "bellion" "$CNF_ORIG" 2>/dev/null && ok "Hook CNF activo"        || { err "Hook CNF no activo";     VERIFY_ERRORS=$((VERIFY_ERRORS+1)); }
[[ -f "$CNF_BACKUP" ]]                    && ok "Backup original OK"     || warn "Sin backup del original (puede ser normal)"

TOTAL_ERRORS=$((ERRORS + VERIFY_ERRORS))

echo ""
if [[ $TOTAL_ERRORS -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║  ✓ Instalación completa y verificada                 ║"
    echo "║                                                      ║"
    echo "║  Automático: escribe cualquier cmd inexistente       ║"
    echo "║  Manual:     bellion ffmpeg                          ║"
    echo "║  Desinstalar: sudo bash uninstall.sh                 ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
else
    echo -e "${YELLOW}${BOLD}"
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║  ⚠ Instalación completada con $TOTAL_ERRORS advertencia(s)         ║"
    echo "║    Revisa los mensajes de error arriba               ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
fi
