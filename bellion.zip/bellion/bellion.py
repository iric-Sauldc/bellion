#!/usr/bin/env python3
"""
bellion — TUI para encontrar e instalar paquetes de comandos no encontrados.
Busca en apt, snap y flatpak. Se activa automáticamente via command-not-found.
"""

import subprocess
import sys
import shutil
import os
import logging
from dataclasses import dataclass, field
from typing import Optional

# ── Silenciar logs de textual para no contaminar stderr ─────────
logging.disable(logging.CRITICAL)

try:
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Horizontal, Vertical
    from textual.reactive import reactive
    from textual.widgets import Header, Footer, Input, DataTable, Static, LoadingIndicator
    from textual import work
    from rich.text import Text
except ImportError:
    print("Error: dependencias no encontradas. Reinstala bellion.", file=sys.stderr)
    sys.exit(1)


# ─────────────────────────── Helpers ────────────────────────────

def _run(cmd: list[str], timeout: int = 10) -> Optional[str]:
    """Ejecuta un comando y retorna stdout, o None si falla."""
    try:
        return subprocess.check_output(
            cmd, stderr=subprocess.DEVNULL,
            text=True, timeout=timeout
        )
    except Exception:
        return None


def _run_lines(cmd: list[str], timeout: int = 10) -> list[str]:
    out = _run(cmd, timeout)
    return out.strip().splitlines() if out else []


# ─────────────────────────── Data ───────────────────────────────

@dataclass
class Package:
    name: str
    version: str
    description: str
    source: str        # "apt" | "snap" | "flatpak"
    provides: str      # binario/comando que provee
    installed: bool = False
    extra: dict = field(default_factory=dict)


# ─────────────────────────── Backends ───────────────────────────

def _apt_pkg_info(pkg_name: str) -> tuple[str, str]:
    """Retorna (version, descripcion) de un paquete apt."""
    version, desc = "—", "Sin descripción"
    out = _run(["apt-cache", "show", "--no-all-versions", pkg_name], timeout=6)
    if not out:
        return version, desc
    for line in out.splitlines():
        if line.startswith("Version:") and version == "—":
            version = line.split(":", 1)[1].strip()
        if (line.startswith("Description-es:") or line.startswith("Description:")) and desc == "Sin descripción":
            desc = line.split(":", 1)[1].strip()
    return version, desc


def _apt_is_installed(pkg_name: str) -> bool:
    out = _run(["dpkg-query", "-W", "-f=${Status}", pkg_name], timeout=4)
    return bool(out and "install ok installed" in out)


def search_apt(command: str) -> list[Package]:
    results: list[Package] = []
    seen: set[str] = set()

    def add_pkg(pkg_name: str, provides: str) -> None:
        if pkg_name in seen:
            return
        seen.add(pkg_name)
        ver, desc = _apt_pkg_info(pkg_name)
        installed = _apt_is_installed(pkg_name)
        results.append(Package(
            name=pkg_name, version=ver, description=desc,
            source="apt", provides=provides, installed=installed,
        ))

    # 1. apt-file: búsqueda exacta por binario
    if shutil.which("apt-file"):
        for prefix in (f"/usr/bin/{command}", f"/usr/sbin/{command}", f"/bin/{command}"):
            for line in _run_lines(["apt-file", "search", "--fixed-string", prefix], timeout=12):
                if ":" in line:
                    pkg = line.split(":", 1)[0].strip()
                    if pkg:
                        add_pkg(pkg, prefix)
            if results:
                break  # con /usr/bin ya es suficiente normalmente

    # 2. command-not-found db (si existe)
    if not results and os.path.exists("/var/lib/command-not-found/commands.db"):
        out = _run(["python3", "-c",
            f"import sqlite3; "
            f"db=sqlite3.connect('/var/lib/command-not-found/commands.db'); "
            f"[print(r[0]) for r in db.execute(\"SELECT package FROM commands WHERE command=?\", ('{command}',))]"
        ], timeout=5)
        if out:
            for pkg in out.strip().splitlines():
                if pkg:
                    add_pkg(pkg.strip(), command)

    # 3. apt-cache: nombre exacto primero, luego búsqueda amplia
    if not results:
        for search_term in (f"^{command}$", command):
            lines = _run_lines(["apt-cache", "search", "--names-only", search_term], timeout=8)
            if not lines and search_term == f"^{command}$":
                lines = _run_lines(["apt-cache", "search", command], timeout=8)
            for line in lines[:8]:
                parts = line.split(" - ", 1)
                if len(parts) == 2:
                    add_pkg(parts[0].strip(), command)
            if results:
                break

    return results[:10]


def _snap_is_installed(name: str) -> bool:
    out = _run(["snap", "list", "--unicode=never", name], timeout=5)
    return bool(out and name in out)


def search_snap(command: str) -> list[Package]:
    if not shutil.which("snap"):
        return []
    # Verificar que snapd está activo
    if _run(["snap", "version"], timeout=4) is None:
        return []
    results = []
    lines = _run_lines(["snap", "find", "--narrow", command], timeout=15)
    if not lines:
        lines = _run_lines(["snap", "find", command], timeout=15)
    for line in lines[1:8]:  # saltar header
        parts = line.split(None, 4)
        if len(parts) < 2:
            continue
        name = parts[0]
        version = parts[1] if len(parts) > 1 else "—"
        publisher = parts[2] if len(parts) > 2 else ""
        desc = parts[4].strip() if len(parts) > 4 else ""
        results.append(Package(
            name=name, version=version, description=desc,
            source="snap", provides=command, installed=_snap_is_installed(name),
            extra={"publisher": publisher},
        ))
    return results


def _flatpak_is_installed(app_id: str) -> bool:
    out = _run(["flatpak", "info", app_id], timeout=5)
    return bool(out)


def search_flatpak(command: str) -> list[Package]:
    if not shutil.which("flatpak"):
        return []
    results = []
    lines = _run_lines(["flatpak", "search", "--columns=name,description,application,version", command], timeout=15)
    if not lines:
        lines = _run_lines(["flatpak", "search", command], timeout=15)
    for line in lines[1:8]:
        parts = line.split("\t")
        if len(parts) < 1:
            continue
        name    = parts[0].strip() if len(parts) > 0 else ""
        desc    = parts[1].strip() if len(parts) > 1 else ""
        app_id  = parts[2].strip() if len(parts) > 2 else ""
        version = parts[3].strip() if len(parts) > 3 else "—"
        if not name:
            continue
        results.append(Package(
            name=name, version=version, description=desc,
            source="flatpak", provides=command,
            installed=_flatpak_is_installed(app_id),
            extra={"app_id": app_id},
        ))
    return results


# ─────────────────────────── Instalación ────────────────────────

_TERMINALS = [
    # (binario,          args_previos_al_script)
    ("gnome-terminal",  ["--wait", "--", "bash", "-c"]),
    ("konsole",         ["--noclose", "-e", "bash", "-c"]),
    ("xfce4-terminal",  ["--hold", "-e"]),
    ("mate-terminal",   ["-e"]),
    ("tilix",           ["-e", "bash", "-c"]),
    ("alacritty",       ["-e", "bash", "-c"]),
    ("kitty",           ["bash", "-c"]),
    ("wezterm",         ["start", "--", "bash", "-c"]),
    ("foot",            ["bash", "-c"]),
    ("lxterminal",      ["-e"]),
    ("xterm",           ["-hold", "-e", "bash", "-c"]),
    ("urxvt",           ["-hold", "-e", "bash", "-c"]),
    ("st",              ["-e", "bash", "-c"]),
]


def _find_terminal() -> Optional[tuple[str, list[str]]]:
    # Preferir la terminal del entorno actual si está definida
    preferred = os.environ.get("TERMINAL", "")
    if preferred and shutil.which(preferred):
        for binary, args in _TERMINALS:
            if binary == preferred:
                return binary, args
    for binary, args in _TERMINALS:
        if shutil.which(binary):
            return binary, args
    return None


def install_package(pkg: Package) -> tuple[bool, str]:
    if pkg.source == "apt":
        install_cmd = f"sudo apt install -y {pkg.name}"
    elif pkg.source == "snap":
        install_cmd = f"sudo snap install {pkg.name}"
    elif pkg.source == "flatpak":
        app_id = pkg.extra.get("app_id") or pkg.name
        install_cmd = f"flatpak install -y {app_id}"
    else:
        return False, "Fuente desconocida"

    bar = "─" * 40
    inner = (
        f"echo '{bar}';"
        f"echo '  bellion — instalando {pkg.name}';"
        f"echo '  fuente: {pkg.source}';"
        f"echo '{bar}';"
        f"echo '';"
        f"{install_cmd}; EXIT=$?;"
        f"echo '';"
        f"echo '{bar}';"
        f"if [ $EXIT -eq 0 ]; then"
        f"  echo '  ✓ Instalación completada exitosamente.';"
        f"else"
        f"  echo '  ✗ Error durante la instalación (código '$EXIT').';"
        f"  echo '  Puedes correr manualmente:';"
        f"  echo '    {install_cmd}';"
        f"fi;"
        f"echo '{bar}';"
        f"echo '';"
        f"read -p '  Presiona Enter para cerrar...' _"
    )

    terminal = _find_terminal()
    if terminal is None:
        # Sin entorno gráfico: ejecutar inline (SSH, TTY puro)
        try:
            ret = subprocess.run(install_cmd, shell=True, timeout=300).returncode
            if ret == 0:
                return True, f"✓ {pkg.name} instalado"
            return False, f"✗ Error (código {ret})"
        except subprocess.TimeoutExpired:
            return False, "✗ Tiempo de espera agotado (300s)"
        except Exception as e:
            return False, f"✗ {e}"

    binary, args = terminal
    try:
        # Para terminales que esperan un string final vs lista de args
        if binary in ("xfce4-terminal", "mate-terminal", "lxterminal"):
            cmd = [binary] + args + [f"bash -c {repr(inner)}"]
        else:
            cmd = [binary] + args + [inner]

        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return True, f"↗ Instalando {pkg.name} vía {pkg.source} — revisa la ventana que se abrió"
    except FileNotFoundError:
        return False, f"✗ Terminal '{binary}' no encontrada"
    except PermissionError:
        return False, f"✗ Sin permisos para ejecutar '{binary}'"
    except Exception as e:
        return False, f"✗ Error al abrir terminal: {e}"


# ─────────────────────────── TUI ────────────────────────────────

SOURCE_COLORS = {"apt": "#f5871f", "snap": "#82aaff", "flatpak": "#c792ea"}
SOURCE_LABELS = {"apt": "APT", "snap": "SNAP", "flatpak": "FLATPAK"}


class StatusBar(Static):
    message: reactive[str] = reactive("")
    def render(self) -> str:
        return self.message
    def show(self, msg: str) -> None:
        self.message = msg


class DetailPanel(Static):
    pkg: reactive[Optional[Package]] = reactive(None)

    def render(self) -> Text:
        if self.pkg is None:
            return Text("\n  Selecciona un paquete para ver detalles", style="dim italic")
        p = self.pkg
        color = SOURCE_COLORS.get(p.source, "white")
        t = Text()
        t.append(f"\n {p.name} ", style=f"bold white on {color}")
        if p.installed:
            t.append(" INSTALADO ", style="bold black on #a3e635")
        t.append("\n\n")
        t.append("  Fuente:      ", style="dim"); t.append(SOURCE_LABELS.get(p.source, p.source), style=f"bold {color}"); t.append("\n")
        t.append("  Versión:     ", style="dim"); t.append(p.version, style="bold cyan"); t.append("\n")
        t.append("  Provee:      ", style="dim"); t.append(p.provides, style="green"); t.append("\n")
        if p.source == "flatpak" and p.extra.get("app_id"):
            t.append("  App ID:      ", style="dim"); t.append(p.extra["app_id"], style="yellow"); t.append("\n")
        if p.source == "snap" and p.extra.get("publisher"):
            t.append("  Publicador:  ", style="dim"); t.append(p.extra["publisher"], style="yellow"); t.append("\n")
        t.append("\n  Descripción:\n  ", style="dim")
        # Wrap descripción a ~35 chars
        words = p.description.split()
        line_len = 0
        for word in words:
            if line_len + len(word) > 32:
                t.append("\n  "); line_len = 0
            t.append(word + " ", style="white"); line_len += len(word) + 1
        t.append("\n\n")
        if p.installed:
            t.append("  Ya está instalado.\n", style="dim green")
        else:
            t.append("  ", style="dim")
            t.append("Enter", style="bold white")
            t.append(" / ", style="dim")
            t.append("i", style="bold white")
            t.append(" para instalar\n", style="dim")
        return t


class BellionApp(App):
    CSS = """
    Screen { background: #1a1b26; color: #c0caf5; }

    Header { background: #16161e; color: #7aa2f7; text-style: bold; height: 1; }
    Footer { background: #16161e; color: #565f89; height: 1; }

    #search-bar {
        height: 3; padding: 0 1;
        background: #16161e; border-bottom: solid #292e42;
    }
    #search-input {
        background: #1f2335; border: solid #3b4261; color: #c0caf5; width: 1fr;
    }
    #search-input:focus { border: solid #7aa2f7; }

    #main-container { height: 1fr; }

    #table-panel { width: 2fr; border-right: solid #292e42; }

    #detail-panel { width: 1fr; padding: 0 1; background: #1f2335; }

    DataTable { background: #1a1b26; height: 1fr; }
    DataTable > .datatable--header { background: #292e42; color: #7aa2f7; text-style: bold; }
    DataTable > .datatable--cursor { background: #2d3f76; color: #c0caf5; }
    DataTable > .datatable--hover  { background: #1f2335; }

    #loading { height: 3; content-align: center middle; display: none; }
    #loading.visible { display: block; }
    LoadingIndicator { color: #7aa2f7; }

    #status-bar {
        height: 1; padding: 0 1;
        background: #16161e; color: #565f89; border-top: solid #292e42;
    }
    """

    BINDINGS = [
        Binding("ctrl+q", "quit",         "Salir"),
        Binding("i",      "install",       "Instalar"),
        Binding("escape", "clear_search",  "Limpiar"),
        Binding("f5",     "refresh",       "Buscar de nuevo"),
        Binding("tab",    "focus_table",   "Tabla"),
    ]

    def __init__(self, initial_command: str = "") -> None:
        super().__init__()
        self.initial_command = initial_command.strip()
        self.packages: list[Package] = []
        self.selected_pkg: Optional[Package] = None

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Horizontal(id="search-bar"):
            yield Input(
                placeholder="  Escribe un comando… (ej: ffmpeg, gimp, node)",
                id="search-input",
                value=self.initial_command,
            )
        with Horizontal(id="main-container"):
            with Vertical(id="table-panel"):
                yield LoadingIndicator(id="loading")
                yield DataTable(id="pkg-table", cursor_type="row")
            yield DetailPanel(id="detail-panel")
        yield StatusBar(id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        t = self.query_one("#pkg-table", DataTable)
        t.add_columns("Fuente", "Paquete", "Versión", "Provee", "Descripción", "Estado")
        if self.initial_command:
            self.set_timer(0.05, lambda: self._trigger_search(self.initial_command))
        else:
            self.query_one("#search-input", Input).focus()

    # ── Búsqueda ────────────────────────────────────────────────

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input.id != "search-input":
            return
        cmd = event.value.strip()
        if len(cmd) >= 2:
            self._trigger_search(cmd)
        elif not cmd:
            self._clear_table()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "search-input":
            self._trigger_search(event.value.strip())

    def _trigger_search(self, command: str) -> None:
        if not command:
            return
        self._clear_table()
        self._set_loading(True)
        self._status(f"Buscando '{command}' en apt, snap y flatpak…")
        self._search_worker(command)

    @work(exclusive=True, thread=True)
    def _search_worker(self, command: str) -> None:
        try:
            results: list[Package] = []
            results.extend(search_apt(command))
            results.extend(search_snap(command))
            results.extend(search_flatpak(command))
        except Exception as e:
            results = []
            self.call_from_thread(self._status, f"Error durante búsqueda: {e}")
        self.packages = results
        self.call_from_thread(self._populate_table, results, command)

    def _populate_table(self, results: list[Package], command: str) -> None:
        self._set_loading(False)
        table = self.query_one("#pkg-table", DataTable)
        table.clear()
        if not results:
            self._status(f"No se encontraron paquetes para '{command}'")
            return
        for pkg in results:
            color = SOURCE_COLORS.get(pkg.source, "white")
            desc = (pkg.description[:52] + "…") if len(pkg.description) > 52 else pkg.description
            ver  = (pkg.version[:16]      + "…") if len(pkg.version)      > 16 else pkg.version
            table.add_row(
                Text(SOURCE_LABELS.get(pkg.source, pkg.source), style=f"bold {color}"),
                Text(pkg.name,    style="bold white"),
                Text(ver,         style="cyan"),
                Text(pkg.provides, style="#a9dc76"),
                Text(desc,        style="dim"),
                Text("✓ instalado", style="green bold") if pkg.installed else Text("—", style="dim"),
            )
        apt_n     = sum(1 for p in results if p.source == "apt")
        snap_n    = sum(1 for p in results if p.source == "snap")
        flatpak_n = sum(1 for p in results if p.source == "flatpak")
        self._status(
            f"{len(results)} resultado(s) para '{command}'  —  "
            f"apt:{apt_n}  snap:{snap_n}  flatpak:{flatpak_n}"
        )

    # ── Selección ───────────────────────────────────────────────

    def _sync_detail(self, idx: int) -> None:
        if 0 <= idx < len(self.packages):
            self.selected_pkg = self.packages[idx]
            self.query_one("#detail-panel", DetailPanel).pkg = self.selected_pkg

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        self._sync_detail(event.cursor_row)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        self._sync_detail(event.cursor_row)
        self.action_install()

    # ── Instalación ─────────────────────────────────────────────

    def action_install(self) -> None:
        if not self.selected_pkg:
            self._status("Selecciona un paquete primero (↑↓)")
            return
        if self.selected_pkg.installed:
            self._status(f"'{self.selected_pkg.name}' ya está instalado.")
            return
        self._status(f"Abriendo instalador para {self.selected_pkg.name}…")
        self._install_worker(self.selected_pkg)

    @work(exclusive=False, thread=True)
    def _install_worker(self, pkg: Package) -> None:
        ok, msg = install_package(pkg)
        if ok:
            pkg.installed = True
        self.call_from_thread(self._status, msg)

    def on_key(self, event) -> None:
        if event.key == "i":
            self.action_install()

    # ── Acciones ────────────────────────────────────────────────

    def action_clear_search(self) -> None:
        self.query_one("#search-input", Input).value = ""
        self._clear_table()
        self.query_one("#search-input", Input).focus()

    def action_refresh(self) -> None:
        val = self.query_one("#search-input", Input).value.strip()
        if val:
            self._trigger_search(val)

    def action_focus_table(self) -> None:
        self.query_one("#pkg-table", DataTable).focus()

    def _clear_table(self) -> None:
        self.query_one("#pkg-table", DataTable).clear()
        self.packages = []
        self.selected_pkg = None
        self.query_one("#detail-panel", DetailPanel).pkg = None

    def _set_loading(self, visible: bool) -> None:
        el = self.query_one("#loading")
        if visible:
            el.add_class("visible")
        else:
            el.remove_class("visible")

    def _status(self, msg: str) -> None:
        try:
            self.query_one("#status-bar", StatusBar).show(msg)
        except Exception:
            pass


# ─────────────────────────── Entry point ────────────────────────

def main() -> None:
    # Validar que hay un comando o argumento
    command = ""
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        # Ignorar flags de help/version sin crashear
        if arg in ("-h", "--help"):
            print("Uso: bellion [comando]")
            print("  Si se omite el comando, abre la TUI vacía para buscar.")
            sys.exit(0)
        if arg in ("-v", "--version"):
            print("bellion 1.0.0")
            sys.exit(0)
        command = arg

    app = BellionApp(initial_command=command)
    try:
        app.run()
    except Exception as e:
        print(f"Error al iniciar bellion: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
