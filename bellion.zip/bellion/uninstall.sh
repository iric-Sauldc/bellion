#!/usr/bin/env bash
# bellion — desinstalador
# Restaura el sistema exactamente como estaba antes de instalar bellion

set -uo pipefail

CNF_ORIG="/usr/lib/command-not-found"
CNF_BACKUP="/usr/lib/command-not-found.orig"
BIN_BELLION="/usr/local/bin/bellion"
INSTALL_DIR="/usr/local/share/bellion"
FISH_HOOK="/usr/share/fish/vendor_functions.d/fish_command_not_found.fish"
ERRORS=0

# ── Colores ───────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BOLD='\033[1m'; RESET='\033[0m'
ok()   { echo -e "  ${GREEN}✓${RESET} $*"; }
warn() { echo -e "  ${YELLOW}⚠${RESET} $*"; }
err()  { echo -e "  ${RED}✗${RESET} $*"; ERRORS=$((ERRORS+1)); }
step() { echo -e "\n${BOLD}→ $*${RESET}"; }

# ── Debe correr como root ─────────────────────────────────────────
if [[ $EUID -ne 0 ]]; then
    echo "Este desinstalador necesita sudo."
    exec sudo bash "$0" "$@"
fi

echo -e "${BOLD}"
echo "╔══════════════════════════════════════╗"
echo "║       bellion — desinstalador        ║"
echo "╚══════════════════════════════════════╝"
echo -e "${RESET}"

# ─────────────────────────────────────────────────────────────────
# PASO 1 — Restaurar /usr/lib/command-not-found
# Tres escenarios posibles:
#   A) Backup existe → restaurar directo
#   B) Backup no existe, hook es nuestro → reinstalar desde apt
#   C) El archivo no es nuestro hook → no tocar nada
# ─────────────────────────────────────────────────────────────────
step "Restaurando command-not-found..."

CNF_IS_OURS=false
if [[ -f "$CNF_ORIG" ]] && grep -q "bellion" "$CNF_ORIG" 2>/dev/null; then
    CNF_IS_OURS=true
fi

if [[ "$CNF_IS_OURS" == false ]] && [[ ! -f "$CNF_BACKUP" ]]; then
    ok "command-not-found no fue modificado por bellion — nada que restaurar"

elif [[ -f "$CNF_BACKUP" ]]; then
    # ── Escenario A: restaurar desde backup ──────────────────────
    cp "$CNF_BACKUP" "$CNF_ORIG"
    chmod 755 "$CNF_ORIG"
    rm -f "$CNF_BACKUP"

    # Verificar que el backup no contenía bellion (backup corrupto)
    if grep -q "bellion" "$CNF_ORIG" 2>/dev/null; then
        err "El archivo de backup también contiene referencias a bellion"
        err "El backup estaba corrupto. Reinstalando desde apt..."
        if apt-get install -y --reinstall command-not-found -q 2>/dev/null; then
            ok "command-not-found reinstalado desde apt"
        else
            warn "No se pudo reinstalar desde apt"
            warn "Instalando handler mínimo funcional..."
            _install_minimal_cnf
        fi
    else
        ok "command-not-found restaurado desde backup"
    fi

elif [[ "$CNF_IS_OURS" == true ]] && [[ ! -f "$CNF_BACKUP" ]]; then
    # ── Escenario B: hook nuestro, sin backup ────────────────────
    warn "Nuestro hook está activo pero no hay backup del original"
    echo "  → Intentando reinstalar command-not-found desde apt..."

    if apt-get install -y --reinstall command-not-found -q 2>/dev/null; then
        ok "command-not-found reinstalado desde apt"
    else
        warn "apt no pudo reinstalar command-not-found"
        warn "Instalando handler mínimo funcional (no rompe el shell)..."
        cat > "$CNF_ORIG" << 'MINIMAL'
#!/usr/bin/env python3
# command-not-found mínimo instalado por bellion uninstall
# Para restaurar el original: sudo apt install --reinstall command-not-found
import sys
cmd = sys.argv[1] if len(sys.argv) > 1 else ""
if cmd:
    print(f"{cmd}: comando no encontrado", file=sys.stderr)
sys.exit(127)
MINIMAL
        chmod 755 "$CNF_ORIG"
        warn "Handler mínimo instalado. Para el original: sudo apt install --reinstall command-not-found"
    fi
fi

# Verificación final: confirmar que bellion no está en el CNF activo
if [[ -f "$CNF_ORIG" ]] && grep -q "bellion" "$CNF_ORIG" 2>/dev/null; then
    err "CRÍTICO: el hook de bellion sigue activo en $CNF_ORIG"
    err "Restauración manual: sudo apt install --reinstall command-not-found"
else
    ok "Hook de bellion eliminado del sistema"
fi

# ─────────────────────────────────────────────────────────────────
# PASO 2 — Hook de Fish
# ─────────────────────────────────────────────────────────────────
step "Verificando hook de Fish..."

if [[ -f "$FISH_HOOK" ]]; then
    if grep -q "bellion" "$FISH_HOOK" 2>/dev/null; then
        rm -f "$FISH_HOOK"
        ok "Hook de Fish eliminado"
    else
        ok "El hook de Fish en $FISH_HOOK no es de bellion — no tocado"
    fi
else
    ok "No hay hook de Fish que eliminar"
fi

# ─────────────────────────────────────────────────────────────────
# PASO 3 — Binario y archivos
# ─────────────────────────────────────────────────────────────────
step "Eliminando archivos de bellion..."

if [[ -f "$BIN_BELLION" ]]; then
    rm -f "$BIN_BELLION"
    ok "/usr/local/bin/bellion eliminado"
else
    ok "/usr/local/bin/bellion ya no existía"
fi

if [[ -d "$INSTALL_DIR" ]]; then
    rm -rf "$INSTALL_DIR"
    ok "$INSTALL_DIR eliminado (venv incluido)"
else
    ok "$INSTALL_DIR ya no existía"
fi

# ─────────────────────────────────────────────────────────────────
# PASO 4 — Verificación final
# ─────────────────────────────────────────────────────────────────
step "Verificación final..."

[[ ! -f "$BIN_BELLION" ]]  && ok "Binario eliminado"      || err "Binario sigue en $BIN_BELLION"
[[ ! -d "$INSTALL_DIR" ]]  && ok "Directorio eliminado"   || err "Directorio sigue en $INSTALL_DIR"
[[ ! -f "$CNF_BACKUP" ]]   && ok "Backup limpiado"        || warn "Backup residual en $CNF_BACKUP"

if grep -q "bellion" "$CNF_ORIG" 2>/dev/null; then
    err "ADVERTENCIA: $CNF_ORIG aún contiene referencias a bellion"
else
    ok "command-not-found limpio"
fi

echo ""
if [[ $ERRORS -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}"
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║  ✓ Desinstalación completa                           ║"
    echo "║    .bashrc, .zshrc y dotfiles intactos              ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
else
    echo -e "${YELLOW}${BOLD}"
    echo "╔══════════════════════════════════════════════════════╗"
    echo "║  ⚠ Desinstalación con $ERRORS error(s)                      ║"
    echo "║    Revisa los mensajes de error arriba               ║"
    echo "║                                                      ║"
    echo "║  Restauración manual del CNF:                        ║"
    echo "║    sudo apt install --reinstall command-not-found    ║"
    echo "╚══════════════════════════════════════════════════════╝"
    echo -e "${RESET}"
fi
